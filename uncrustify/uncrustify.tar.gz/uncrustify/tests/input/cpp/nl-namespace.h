namespace ns1 {

   void *foo(void);
   void bar(void);

}

namespace ns2
{

   void *foo(void);
   void bar(void);

}

