struct S
{
int one, two;
S(int i = 1)
{
one = i;
two = i + i;
}
bool check() const
{
return one == 1;
}
};

struct S
{
enum {
twentythree = 23,
fortytwoseven = 427
};
int one, two;
S(int i = 1)
{
one = i;
two = i + i;
}
bool check() const
{
return one == 1;
}
};

static  uint jhash(K x)
    {
        ubyte *k;
        uint  a,
              b,
              c;

        uint  
a,
              b,
              c;

        len = x.length;
}

const char *token_names[] =
{
   [CT_POUND]   = "POUND",
   [CT_PREPROC] = "PREPROC",
};

struct whoopee *
foo4(
   int param1,
   int param2,
   char *param2
   );
