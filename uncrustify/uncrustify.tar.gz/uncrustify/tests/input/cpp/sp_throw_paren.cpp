
void foo()
{
   throw(x);
   throw   (y);
   throw (z);
}
