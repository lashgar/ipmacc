
#define outpsize
#define some(f)\
foo(f)

class CRC
{
public:
int foo;
// Initial CRC Start Value
 #define 24BITCRC ((ULONG) 0x00864CFB) // This line is not aligned with the other lines
char ch;
#define MULTI LINE DEFINE \
 in column 0 \
that spans
//// Operations ////
public:
...
}

{
#if defined(WIN32)
	SYSTEMTIME st;
	DWORD ThreadId;
#else
	struct timeval mytv;
	struct tm *mytm;
	pid_t ProcessId;
#endif

#if SOME COND
	(void)loop;
#endif
}

