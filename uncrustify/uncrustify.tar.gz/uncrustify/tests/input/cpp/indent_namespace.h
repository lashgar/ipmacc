namespace ns1 {

   void bar1(void);

   class foo1
   {
      int i1;
   };
}

namespace ns2
{

   void bar2(void);

   class foo2
   {
      int i2;
   };
}

namespace
{

   void bar3(void);
   class foo3
   {
      int i3;
   };

}

