#include <string>

class CFoo
{
int foo1(int arg);
int foo2();
};

int CFoo::foo1(int arg)
{
}

int CFoo::foo2()
{
}

int CFoo::operator +()
{
}

map<string, int> func()
{
  // some codes
}

int some_func(void)
{
}

