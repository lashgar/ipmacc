#include <string>

namespace bar
{

class CFoo
{
int foo1(int arg);
private:
int foo2()
{
}
};

int CFoo::foo1(int arg, char arg2)
{
}

int CFoo::foo2()
{
}

int CFoo::operator +()
{
}

map<string, int> func()
{
  // some codes
}

int some_func(void)
{
}

}
