void A::f()
{}
