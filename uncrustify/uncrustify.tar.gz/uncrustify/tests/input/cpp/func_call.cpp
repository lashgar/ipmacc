void f()
{
    auto x = func1(
        arg,
        arg);
}

void f()
{
    return func2(
        arg,
        arg);
}

