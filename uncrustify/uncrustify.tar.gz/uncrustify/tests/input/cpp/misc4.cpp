struct X {
 void operator deleteme(void*);
 void deallocate(int*p){
  operator delete((void*)p);
  delete((void*)q);
 } 
};

int f(bool b) {
typedef int mytype;
if (b)
return int(42.0);
else
return mytype(42.0);
}

struct X {
double f(int n)
{
return double(n);
}
};

inline value_type operator () () const
     {
         return (double(rnd32()) * (0.5 / 0x80000000));
     }

