void function(){
int n;
float f;
anotherFunction();
char foo;
somethingelse();
} 
