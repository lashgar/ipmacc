

class MyClass
{
public:

struct something
{
int one;
int two;
}

MyClass()
{
}

void oneFunction()
{
if (1 == 0)
{
instructions;
}
}
};
