namespace boo3 {
int Fun1()
{
	return 42;
}
}

namespace boo4 {
 int Fun2()
 {
 	int a = 7;
 	int b = 8;
 	return a+b;
 }
}
