#include <vector>
void f(std::vector<int> * vip, std::vector<int> & vir);

