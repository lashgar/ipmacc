void CMyClass::myFunction()
{
CMyReferencePointer & tmpPointer = (CMyReferencePointer & )getMyValue();
}

