%:include <iostream>                // #include <iostream>
int main(int argc, char *argv[]) <% // {
int array<:10:>;                    // int array[10];
%>                                  // }

