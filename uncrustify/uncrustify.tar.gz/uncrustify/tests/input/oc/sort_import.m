// should be ddd, eee, fff
#import "ddd"
#import "fff"
#import "eee"

// should be aaa, ccc
#import "ccc"
#import "aaa"
// should be just bbb
#import "bbb"

