
- (void)moreScannedData:(Image*)img from:(int)start to:(int)stop;
-(void)moreScannedData : (Image*)img from : (int)start to : (int)stop;

public bool Enabled
{
    NSString* whatever = @"some lovely text, the fox and co";

    a = (enderedImage->h - toplines - bottomlines);
}

