// The semicolons at the end of these declarations are not superfluous.
typedef NS_ENUM (NSUInteger, MyEnum) {MyValue1, MyValue2, MyValue3};
typedef NS_OPTIONS (NSUInteger, MyBitmask) {MyBit1, MyBit2, MyBit3};
