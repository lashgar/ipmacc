[self findstart:&startBarcode end:&endBarcode forLine:greenScalePixels derivative:greenDerivative centerAt:xAxisCenterPoint min:&minValue max:&maxValue];

[self findstart:&startBarcode 
            end:&endBarcode 
        forLine:greenScalePixels 
     derivative:greenDerivative 
       centerAt:xAxisCenterPoint 
            min:&minValue 
            max:&maxValue];

