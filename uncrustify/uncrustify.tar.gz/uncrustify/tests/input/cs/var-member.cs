namespace Foo.Man.Chu
{
   /// <summary>
   /// Summary description for MainForm.
   /// </summary>
   public class MainForm : System.Windows.Forms.Form
   {
      #region Initialize the private properties
      private System.Windows.Forms.MenuItem File;
      private    System.Windows.Forms.MenuItem Exit;
      private   System.Windows.Forms.Label label1;
      private System.Windows.Forms.Label label2;
      private Properties Prop;
      private About      Abt;
      public MainForm    mainform;
      private   System.Windows.Forms.MenuItem menuItem1;
      private  System.Windows.Forms.Timer timer1;
      private     System.ComponentModel.IContainer components;
      protected string   strTitle;
      #endregion

   }
}
   
