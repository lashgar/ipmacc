public class Class1
{
   public unsafe bool GetValue ()
       {
           return true;
       }
}
