public bool Enabled
{
get { return enabled; }
}


public bool Enabled
{
get
{
return enabled;
}
}

