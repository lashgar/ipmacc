void foo()
{
try
{
;
}
catch (Exception e)
{
;
}
finally {
;
}
bar();

try
{
;
}
catch (Exception e)
{
;
}
catch (Exception e)
{
;
}
finally {
;
}
bar();
}
