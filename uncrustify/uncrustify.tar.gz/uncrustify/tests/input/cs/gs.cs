private string s = "";
public int Amount
{
get
{
;
}
set
{
;
}
}
public EventHandler MyCustomEventHandler
{
add
{
;
}
remove
{
;
}
}
public this[string index]
{
get;
set;
}
private string s2 = "";

