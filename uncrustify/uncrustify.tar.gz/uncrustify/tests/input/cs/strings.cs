void foo()
{
   string s1 = L"C:\\foo\\bar";
   string s2 = S"C:\\foo\\bar";
   string s3 = "This is a \"test\"";
   string s4 = "C:\\";
}

