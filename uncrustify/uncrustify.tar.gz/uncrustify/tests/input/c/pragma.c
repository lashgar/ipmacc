
#pragma do not change anything in this pragma!

// This next bit should parse as '#', pragma, preproc-body, nl-cont, 
//   preproc-body, nl-cont, preproc-body
#pragma multi \
   line \
      pragma

#pragma mark -------- Protected Member Functions ----------------

#pragma some comment follows    // comment

