
int foo(int a, int b)
{
if ( ! (a || b) )
{
return (1);
}
return 0;
}

void fooo()
{
if(enabled) value = 1;

if(enabled && value==100)
{
}

if(value==100)
{
}

if(value==100 && i<15 || enabled)
{
}

if(!failed && (value==100 && i<15) || enabled)
{
}

}

void foo3()
{
   if (strcmp(a, b) == 0 && total < 5)
   {
      add_item(a);
   }

   if (glob_add_path(gd, gd->dir, NULL,
                     (flags & GLOB_MARK) && S_ISDIR(gd->st.st_mode)) != 0)
   {
      bar();
   }
  return ;
}

int foo1(void)
{
   FOO_ERROR("connect: can only connected from state CLOSED", pcb->state == CLOSED, return ERR_ISCONN);
return ERR_OK;
}

int foo2(void)
{

return (-1);
}

void foo(void)
{
if (!value
#ifdef OPTION
|| value == SOMECONST
#endif /* comment */
)
{
}
}

void foo3(void)
{
   if (*p == '-' && p[1] != ']' ?
       *text <= *++p && *text >= last : *text == *p)
   {
      matched = TRUE;
   }
}

