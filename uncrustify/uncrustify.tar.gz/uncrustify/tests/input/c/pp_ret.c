#if 0
int
#else
unsigned
#endif
f()
{
return 0;
}

#ifdef FOO
#define BAR .
#endif

