void foo(void)
{
   int a;
   int b;// comment

   /* comment */
   a = b;
   return;
}
