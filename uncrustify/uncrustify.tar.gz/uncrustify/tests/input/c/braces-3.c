{
   list_for_each(k) {
      if (a)
         if (b)
         {
            c++;
         }
   }
}
