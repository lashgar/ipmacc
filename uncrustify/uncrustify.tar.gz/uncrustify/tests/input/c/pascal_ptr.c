foobar_t*  a;
int  *b;
int *  c;
something no;

char *  main()
{
 int i = (5*3)+2;
}

void foo(int* a, int *b, int * c)
{
}
