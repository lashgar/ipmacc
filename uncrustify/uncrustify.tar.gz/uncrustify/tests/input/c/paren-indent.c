static void *foo(int param1,
   char *param2
    );


static void *foo
(
   int param1,
   char *param2
)
{
   for (
        int i = 0;
       i< 10;
         i++
          )
   {
      bar(
         arg1,
         arg2
         );
      if ( ( abc < bcd )
         &&( 123 < abc )
            )
      {
         none(arg1,
            arg2,
              arg3
            );
      }
   }
}


void CWarningAnalyzer::SetEffect(int FilterNumber
                              ,bool Exclude
                                 , int  Red
                                  , int  Green
                                  , int  Blue
                                   , bool Italic
                                , bool Bold
                                  , bool Underlined
                            )
{
   /* TODO */
}
