void foo(void)
{
   if ((a_really_long_number >
       another_really_long_number) 
       ||
 (some_really_long_bool 
   != another_really_long_bool))
	{		
		foo2();
	} 
}
