int main
(
)
{
   #ifdef useJPLvelocity

      for(i = 0; i < x; i++)
         y++;
   #endif

   return (0);
} /* main */

