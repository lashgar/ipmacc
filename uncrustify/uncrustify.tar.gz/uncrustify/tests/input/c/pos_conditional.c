void foo(void)
{
   // conditional colon
   a = bar() ? 2 :
       3;
   a = bar() ? 2 
       : 3;

   // conditional question
   a = bar() ? 
       2 : 3;
   a = bar() 
       ? 2 : 3;
}
