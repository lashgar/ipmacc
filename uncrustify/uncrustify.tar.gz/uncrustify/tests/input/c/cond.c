
int foo1(bool b, int tv, int fv)
{
   return b   ?   tv   : fv;
}

int foo2(bool b, int tv, int fv)
{
   return b?tv:fv;
}
