void foo(void)
{
   STACK_OF(X509) * st=sk_X509_new_null();
}
