int func(n)  
{  
  int a = foo (); 
  char *a = _("some text");
  char *str = N_("other text");
} 

