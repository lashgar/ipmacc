/*
This is a multiline
comment that should
not be indented
*/
{
    /*
    No trailing spaces

    in this comment
    */
}
