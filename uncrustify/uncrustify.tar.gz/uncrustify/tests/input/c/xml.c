void foo(void)
{
const char *a= "<xml>"
"<data Parent=\"%d\" Name=\"%s\">"
"<Child Id=\"%d\"/>"
"</data>"
"</xml>";
}

