
void foo(void)
{
   drab bar;
   bar = (bat) * r;
   bar = (int) * r;
   bar = (UINT8) * r;
   bar = (time_t) * r;

   a = &arg[dog * 13];
   b = arg[dog * cat];
   hc = "0123456789ABCDEF"[0xf & *val];
}

