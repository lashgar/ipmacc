#define UHI_AOA { \
		.install = uhi_aoa_install, \
		.enable = uhi_aoa_enable, \
		.uninstall = uhi_aoa_uninstall, \
		.sof_notify = NULL, \
}