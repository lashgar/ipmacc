void f()
{
    int    x= 3;
    int b     = 4;
}
