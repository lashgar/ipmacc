void foo()
{
if (a)
  b++;
if (a) {
  b++;
}
if (a)
 if (b)
   c++;

for (i=0;i<5;i++)
  bar(i);
while (i>0)
bar(--i);

}
