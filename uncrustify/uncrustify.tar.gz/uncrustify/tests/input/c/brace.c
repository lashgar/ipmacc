


int function(int arg) {
  int i;
  for (i=0;i<5;i++){
    /* Do something... */
  }
  if(i<0){
  /*Do something else...*/  }

  return 0;
}
