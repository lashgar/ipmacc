void foo(void)
{
   a = 5; b = 3; j = 6;

   for (a = 0; a < j; a++)
   {
      b *= (a + b);
   }
}

struct somestruct { int a; char b; foo c; bar *d; };

struct foo { int a; char *b };

void f()
{
for (;;)
nothing();
foobar();
}
;
