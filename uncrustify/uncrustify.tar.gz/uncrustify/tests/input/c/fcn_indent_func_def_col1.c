#if A
/* dfsdsdfd */
int X;
#endif

#if A
void func1_1(void);
#endif

#if A
#if A
int X1;
void func1_1(void)
{
#if A
/* ttiti */
if (B)
{
#if A
/* dsfdf */
a=5;
#endif
}
#endif
}
int Y1;

    void func1_2(void)
	{
	}
		int Z1;
#endif
#endif

#if A
#if A
int X2;
/* fsdsfd */
void func2_1(void)
{
#if A
/* ttiti */
if (B)
{
#if A
/* dsfdf */
a=5;
#endif
}
#endif
}
		int Y2;
#endif
#endif
