void test(void)
{
b1=a&b||c==d;
b2=(a&b)||c==d;
b3=(a&b||c==d);


if (a==3 && b==2 & c || d && r){}


if (/*test*/a||b){}

if (/*test*/a||/*truc*/b){}

if (a/*test*/||b){}

if (a||/*test*/b){}

 a=3; if ((aaaaaaaaaaaaaaa ==  sqddqsqsdqsdqsd)   &&   (dfdssdfsdfsdfsdfs  || (qsdfsdfsdfqsdfqsdfqsdsd == fsdqfsdfsdfsdf))) { a++;}

while ((aaaaaaaaaaaaaaa ==  sqddqsqsdqsdqsd)   &&   (dfdssdfsdfsdfsdfs  || (qsdfsdfsdfqsdfqsdfqsdsd == fsdqfsdfsdfsdf))) { a++;}
}
