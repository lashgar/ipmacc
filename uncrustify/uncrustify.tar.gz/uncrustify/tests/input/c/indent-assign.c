void foo(void)
{
   int a;
   junk(a = 3);
}

void f()
{
  int x = size_t(1.0) +
    2;
  int y = (size_t(1.0) +
    5);
}
