
void foo()
{
   some.really_long.variable_name
  = another.big.one[55] +
   something_else;

  some.really_long.variable_name =
   another.big.one[55] +
   something_else;

   some.really_long.variable_name = another.big.one[55] +
  something_else;

   a_really_long_assignment_to_test = line_breaks_around_assign_and_arith;

   a_really_long_assignment_to_test = line_breaks_around + assign_and_arith;

}
