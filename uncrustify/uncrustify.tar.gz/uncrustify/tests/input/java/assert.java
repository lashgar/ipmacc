public class JavaClass {

    public static void main(String[] args) {
	/* assert EXPRESSION1 ; */
	assert ( a != null ) && ( b != null );
	/* assert EXPRESSION1 : EXPRESSION2 ; */
        assert ( a != null ) && ( b != null ) : "Message";
    }
}
